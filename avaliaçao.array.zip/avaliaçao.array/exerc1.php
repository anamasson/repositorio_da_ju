<?php
$numeros = [1, 2, 3, 4, 5];

// Impressão de cada elemento do array
foreach ($numeros as $numero) {
    echo $numero . "<br>";
}
?>